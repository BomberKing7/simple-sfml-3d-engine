#include <iostream>
using namespace std;
#include <fstream>
#include <math.h>
int main(){
    ofstream file("diamond.txt");
    float t=2*M_PI;int n=5;
    for(int i=0;i<n;i++){
        file<<"p "<<cos(i*t/n)<<"   "<<sin(i*t/n)<<" 5"<<endl;;
        }
    for(int i=0;i<n;i++){
        file<<"p "<<2*cos(i*t/n)<<"   "<<2*sin(i*t/n)<<" 4"<<endl;;
        
        
        
    }
    file<<"0 0 0";
    }